import paramiko

# Define a dictionary to store sysadmin usernames and passwords
sysadmin_credentials = {
    "amish": "nikit123"
    # Add more sysadmin usernames and passwords as needed
}

# SSH connection settings
vm_hostname = "16.171.17.23"  # Replace with your VM's hostname or IP address
ssh_port = 22  # SSH port (default is 22)

def login_and_execute_command(username, password, hostname, port, command):
    # Create an SSH client
    ssh = paramiko.SSHClient()

    try:
        # Automatically add the server's host key (this is insecure in production)
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # Connect to the VM
        ssh.connect(hostname, port, username, password)

        # Execute a command on the remote VM
        stdin, stdout, stderr = ssh.exec_command(command)

        # Display the command's output
        print("Command Output:")
        print(stdout.read().decode())

        # Check the return status of the command execution
        if stdout.channel.recv_exit_status() != 0:
            print("Command execution failed.")
    
    except paramiko.AuthenticationException as e:
        print(f"Authentication failed: {str(e)}")
    except paramiko.SSHException as e:
        print(f"SSH connection failed: {str(e)}")
    finally:
        # Close the SSH connection
        ssh.close()

# Input from the user
username_input = input("Enter sysadmin username: ")
password_input = input("Enter password: ")

# Validate login and execute a command (replace 'ls' with your desired command)
login_and_execute_command(username_input, password_input, vm_hostname, ssh_port, 'ls -ltra')
