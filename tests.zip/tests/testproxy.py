import paramiko
import requests

def establish_ssh_connection(vm_host, vm_port, vm_username, vm_password, proxy_url, test_url):
    try:
        # Create an SSH client
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # Connect to the VM
        ssh.connect(vm_host, port=vm_port, username=vm_username, password=vm_password)

        # Define proxy settings
        proxies = {
            'http': proxy_url,
            'https': proxy_url
        }

        # Define a test URL (e.g., google.com)
        response = requests.get(test_url, proxies=proxies, timeout=10)

        # Check if the request was successful (HTTP status code 200)
        if response.status_code == 200:
            print("VM can interact with the internet using the provided proxy.")
        else:
            print(f"VM can connect to the internet, but the response status code is {response.status_code}.")
    except Exception as e:
        print(f"VM cannot interact with the internet using the provided proxy. Error: {str(e)}")
    finally:
        # Close the SSH connection
        if ssh:
            ssh.close()

if __name__ == "__main__":
    # VM SSH connection parameters
    vm_host = "16.171.17.23"
    vm_port = 22  # Default SSH port
    vm_username = "amish"
    vm_password = "nikit123"

    # Proxy and test URL
    proxy_url = "http://www.google.com"
    test_url = "http://www.google.com"

    establish_ssh_connection(vm_host, vm_port, vm_username, vm_password, proxy_url, test_url)
