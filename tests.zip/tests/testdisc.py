import paramiko

def get_root_disk_size_ssh(hostname, username, password, port=22):
    try:
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh_client.connect(hostname, port=port, username=username, password=password)

        # Run a command to get the root disk size (assuming Linux)
        stdin, stdout, stderr = ssh_client.exec_command("df / --output=size --block-size=G | tail -n 1")
        root_disk_size_gb = float(stdout.read().decode().strip().rstrip('G'))

        return root_disk_size_gb

    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return None

def is_root_disk_size_valid(size_gb, hostname, username, password):
    root_disk_size = get_root_disk_size_ssh(hostname, username, password)
    if root_disk_size is not None:
        return root_disk_size >= size_gb
    else:
        return False

# Define your VM's SSH connection details
vm_hostname = "16.171.17.23"
vm_username = "amish"
vm_password = "nikit123"

desired_size_gb = 8 # Change this to the desired size

if is_root_disk_size_valid(desired_size_gb, vm_hostname, vm_username, vm_password):
    print(f"Root disk size is {desired_size_gb} GB or larger.")
else:
    print(f"Root disk size is less than {desired_size_gb} GB.")
