import paramiko

def test_ssh_connection(host, port, username, password):
    try:
        # Create an SSH client
        ssh_client = paramiko.SSHClient()

        # Automatically add the server's host key (this is insecure in production)
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # Connect to the remote VM
        ssh_client.connect(host, port, username, password)

        # If the connection is successful, print a success message
        print(f"SSH connection to {host}:{port} established successfully.")

        # Close the SSH connection
        ssh_client.close()

        return True
    except paramiko.AuthenticationException:
        print(f"Failed to authenticate with {host}:{port} using the provided credentials.")
    except paramiko.SSHException as e:
        print(f"SSH error occurred: {str(e)}")
    except Exception as e:
        print(f"An error occurred: {str(e)}")

    return False

if __name__ == "__main__":
    host = "16.171.17.23"
    port = 22  # Default SSH port
    username = "amish"
    password = "nikit123"

    if test_ssh_connection(host, port, username, password):
        print("SSH connectivity test passed.")
    else:
        print("SSH connectivity test failed.")
