import socket
import paramiko

def validate_and_ssh(vm_hostname, vm_username, vm_password, expected_hostname, command):
    # Validate the hostname
    actual_hostname = socket.gethostname()
    if actual_hostname != expected_hostname:
        print(f"Hostname is configured as '{actual_hostname}' but expected '{expected_hostname}'")
        return

    print(f"Hostname is correctly configured as '{expected_hostname}'")

    try:
        # Create an SSH client
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # Connect to the VM
        ssh_client.connect(vm_hostname, username=vm_username, password=vm_password)

        # Execute the command on the VM
        stdin, stdout, stderr = ssh_client.exec_command(command)

        # Read the command output
        output = stdout.read().decode('utf-8')
        error = stderr.read().decode('utf-8')

        print("Command Output:")
        print(output)

        if error:
            print("Error Output:")
            print(error)

        # Close the SSH connection
        ssh_client.close()

    except Exception as e:
        print(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    vm_hostname = "16.171.17.23"          # Replace with the VM's hostname or IP address
    vm_username = "amish"   # Replace with your SSH username
    vm_password = "nikit123"   # Replace with your SSH password
    expected_hostname = "DESKTOP-Q9NHJC3"  # Replace with the expected hostname
    command_to_run = "ls -ltra"        # Replace with the command you want to run

    validate_and_ssh(vm_hostname, vm_username, vm_password, expected_hostname, command_to_run)
