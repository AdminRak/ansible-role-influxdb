import paramiko

def is_user_existing(username, hostname, ssh_username, ssh_password):
    try:
        # Create an SSH client
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # Connect to the VM
        ssh_client.connect(hostname, username=ssh_username, password=ssh_password)

        # Execute the 'id' command remotely
        stdin, stdout, stderr = ssh_client.exec_command(f'id {username}')
        
        # Check if the command was successful (user exists)
        if stdout.channel.recv_exit_status() == 0:
            return True
        else:
            return False

    except paramiko.AuthenticationException:
        print("Authentication failed.")
        return False
    except paramiko.SSHException as e:
        print(f"SSH error: {str(e)}")
        return False
    finally:
        # Close the SSH connection
        ssh_client.close()

# Replace these values with your VM's information
vm_hostname = '16.171.17.23'
ssh_username = 'amish'
ssh_password = 'nikit123'
username_to_check = 'amish'

if is_user_existing(username_to_check, vm_hostname, ssh_username, ssh_password):
    print(f"The user '{username_to_check}' exists on the VM.")
else:
    print(f"The user '{username_to_check}' does not exist on the VM.")
