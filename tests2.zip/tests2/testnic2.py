import paramiko
import sys
import getopt

def count_nic_interfaces_ssh(hostname, port, username, password):
    ssh_client = paramiko.SSHClient()
    ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        ssh_client.connect(hostname, port=port, username=username, password=password)
        stdin, stdout, stderr = ssh_client.exec_command("ifconfig -a | grep -c 'inet addr'")
        num_interfaces = int(stdout.read().decode("utf-8").strip())
        return num_interfaces
    except paramiko.AuthenticationException as auth_error:
        return f"Authentication error: {auth_error}"
    except paramiko.SSHException as ssh_error:
        return f"SSH error: {ssh_error}"
    except Exception as e:
        return f"Connection error: {e}"
    finally:
        ssh_client.close()

def main(argv):
    vm_hostname = ""
    vm_port = 22  # Default SSH port
    vm_username = ""
    vm_password = ""

    try:
        opts, _ = getopt.getopt(argv, "h:P:u:p:", ["hostname=", "port=", "username=", "password="])
    except getopt.GetoptError:
        print("Usage: nic_validation.py -h <hostname> -P <port> -u <username> -p <password>")
        sys.exit(2)

    for opt, arg in opts:
        if opt in ("-h", "--hostname"):
            vm_hostname = arg
        elif opt in ("-P", "--port"):
            vm_port = int(arg)
        elif opt in ("-u", "--username"):
            vm_username = arg
        elif opt in ("-p", "--password"):
            vm_password = arg

    if not all([vm_hostname, vm_username, vm_password]):
        print("Missing required arguments.")
        print("Usage: nic_validation.py -h <hostname> -P <port> -u <username> -p <password>")
        sys.exit(2)

    num_nic_interfaces = count_nic_interfaces_ssh(vm_hostname, vm_port, vm_username, vm_password)

    if num_nic_interfaces >= 2:
        print(f"There are {num_nic_interfaces} NIC interfaces configured.")
    else:
        print(f"There are less than 2 NIC interfaces configured.")

if __name__ == "__main__":
    main(sys.argv[1:])
