import paramiko
import requests
import sys
import getopt

def establish_ssh_connection(vm_host, vm_port, vm_username, vm_password):
    try:
        # Create an SSH client
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # Connect to the VM
        ssh.connect(vm_host, port=vm_port, username=vm_username, password=vm_password)

        return ssh
    except Exception as e:
        print(f"Failed to establish an SSH connection to the VM. Error: {str(e)}")
        sys.exit(1)

def check_internet_with_proxy(ssh, proxy_url, test_url):
    try:
        # Define proxy settings
        proxies = {
            'http': proxy_url,
            'https': proxy_url
        }

        # Define a test URL (e.g., google.com)
        response = requests.get(test_url, proxies=proxies, timeout=10)

        # Check if the request was successful (HTTP status code 200)
        if response.status_code == 200:
            print("VM can interact with the internet using the provided proxy.")
        else:
            print(f"VM can connect to the internet, but the response status code is {response.status_code}.")
    except Exception as e:
        print(f"VM cannot interact with the internet using the provided proxy. Error: {str(e)}")
    finally:
        # Close the SSH connection
        if ssh:
            ssh.close()

def main(argv):
    # Default values
    vm_host = ""
    vm_port = 22
    vm_username = ""
    vm_password = ""
    proxy_url = ""
    test_url = ""

    try:
        opts, _ = getopt.getopt(argv, "h:P:u:p:r:t:", ["host=", "port=", "username=", "password=", "proxy=", "test="])
    except getopt.GetoptError:
        print("Usage: testproxy.py -h <VM host> -P <VM port> -u <VM username> -p <VM password> -r <Proxy URL> -t <Test URL>")
        sys.exit(2)

    for opt, arg in opts:
        if opt == "-h":
            vm_host = arg
        elif opt == "-P":
            vm_port = int(arg)
        elif opt == "-u":
            vm_username = arg
        elif opt == "-p":
            vm_password = arg
        elif opt == "-r":
            proxy_url = arg
        elif opt == "-t":
            test_url = arg

    if not vm_host or not vm_username or not vm_password or not proxy_url or not test_url:
        print("All parameters (-h, -u, -p, -r, -t) are required.")
        sys.exit(2)

    ssh = establish_ssh_connection(vm_host, vm_port, vm_username, vm_password)
    check_internet_with_proxy(ssh, proxy_url, test_url)

if __name__ == "__main__":
    main(sys.argv[1:])
