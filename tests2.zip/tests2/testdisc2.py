import paramiko
import getopt
import sys

def get_root_disk_size_ssh(hostname, username, password, port=22):
    try:
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh_client.connect(hostname, port=port, username=username, password=password)

        # Run a command to get the root disk size (assuming Linux)
        stdin, stdout, stderr = ssh_client.exec_command("df / --output=size --block-size=G | tail -n 1")
        root_disk_size_gb = float(stdout.read().decode().strip().rstrip('G'))

        return root_disk_size_gb

    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return None

def is_root_disk_size_valid(size_gb, hostname, username, password, port=22):
    root_disk_size = get_root_disk_size_ssh(hostname, username, password, port)
    if root_disk_size is not None:
        return root_disk_size >= size_gb
    else:
        return False

def main(argv):
    try:
        opts, args = getopt.getopt(argv, "h:u:P:p:s:", ["hostname=", "username=", "port=", "password=", "size="])
    except getopt.GetoptError:
        print("Usage: vm_disk_size_checker.py -h <hostname> -u <username> -P <port> -p <password> -s <size>")
        sys.exit(2)

    hostname = None
    username = None
    password = None
    port = 22
    size_gb = None

    for opt, arg in opts:
        if opt in ("-h", "--hostname"):
            hostname = arg
        elif opt in ("-u", "--username"):
            username = arg
        elif opt in ("-P", "--port"):
            port = int(arg)
        elif opt in ("-p", "--password"):
            password = arg
        elif opt in ("-s", "--size"):
            size_gb = float(arg)

    if hostname is None or username is None or password is None or size_gb is None:
        print("Usage: vm_disk_size_checker.py -h <hostname> -u <username> -P <port> -p <password> -s <size>")
        sys.exit(2)

    if is_root_disk_size_valid(size_gb, hostname, username, password, port):
        print(f"Root disk size on {hostname} is {size_gb} GB or larger.")
    else:
        print(f"Root disk size on {hostname} is less than {size_gb} GB.")

if __name__ == "__main__":
    main(sys.argv[1:])
