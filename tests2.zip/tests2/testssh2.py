import paramiko
import sys
import getopt

def test_ssh_connection(host, port, username, password):
    try:
        # Create an SSH client
        ssh_client = paramiko.SSHClient()

        # Automatically add the server's host key (this is insecure in production)
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # Connect to the remote VM
        ssh_client.connect(host, port, username, password)

        # If the connection is successful, print a success message
        print(f"SSH connection to {host}:{port} established successfully.")

        # Close the SSH connection
        ssh_client.close()

        return True
    except paramiko.AuthenticationException:
        print(f"Failed to authenticate with {host}:{port} using the provided credentials.")
    except paramiko.SSHException as e:
        print(f"SSH error occurred: {str(e)}")
    except Exception as e:
        print(f"An error occurred: {str(e)}")

    return False

def main(argv):
    host = ""
    port = 22  # Default SSH port
    username = ""
    password = ""

    try:
        opts, args = getopt.getopt(argv, "h:P:u:p:", ["host=", "port=", "username=", "password="])
    except getopt.GetoptError:
        print("Usage: ssh_test.py -h <host> -P <port> -u <username> -p <password>")
        sys.exit(2)

    for opt, arg in opts:
        if opt == "-h":
            host = arg
        elif opt == "-P":
            port = int(arg)
        elif opt == "-u":
            username = arg
        elif opt == "-p":
            password = arg

    if not host or not username or not password:
        print("Usage: ssh_test.py -h <host> -P <port> -u <username> -p <password>")
        sys.exit(2)

    if test_ssh_connection(host, port, username, password):
        print("SSH connectivity test passed.")
    else:
        print("SSH connectivity test failed.")

if __name__ == "__main__":
    main(sys.argv[1:])
