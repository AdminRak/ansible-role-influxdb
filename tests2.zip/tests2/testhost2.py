import socket
import paramiko
import getopt
import sys

def validate_and_ssh(vm_hostname, vm_username, vm_password, expected_hostname, command, ssh_port):
    # Validate the hostname
    actual_hostname = socket.gethostname()
    if actual_hostname != expected_hostname:
        print(f"Hostname is configured as '{actual_hostname}' but expected '{expected_hostname}'")
        return

    print(f"Hostname is correctly configured as '{expected_hostname}'")

    try:
        # Create an SSH client
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # Connect to the VM with the specified port
        ssh_client.connect(vm_hostname, port=ssh_port, username=vm_username, password=vm_password)

        # Execute the command on the VM
        stdin, stdout, stderr = ssh_client.exec_command(command)

        # Read the command output
        output = stdout.read().decode('utf-8')
        error = stderr.read().decode('utf-8')

        print("Command Output:")
        print(output)

        if error:
            print("Error Output:")
            print(error)

        # Close the SSH connection
        ssh_client.close()

    except Exception as e:
        print(f"An error occurred: {str(e)}")

def main(argv):
    vm_hostname = ""
    vm_username = ""
    vm_password = ""
    expected_hostname = ""
    command_to_run = ""
    ssh_port = 22  # Default SSH port

    try:
        opts, args = getopt.getopt(argv, "h:u:p:e:c:P:", ["hostname=", "username=", "password=", "expected=", "command=", "port="])
    except getopt.GetoptError:
        print("Usage: python script.py -h <hostname> -u <username> -p <password> -e <expected_hostname> -c <command> -P <port>")
        sys.exit(2)

    for opt, arg in opts:
        if opt == "-h":
            vm_hostname = arg
        elif opt == "-u":
            vm_username = arg
        elif opt == "-p":
            vm_password = arg
        elif opt == "-e":
            expected_hostname = arg
        elif opt == "-c":
            command_to_run = arg
        elif opt == "-P":
            ssh_port = int(arg)

    if not all([vm_hostname, vm_username, vm_password, expected_hostname, command_to_run]):
        print("All parameters are required.")
        sys.exit(2)

    validate_and_ssh(vm_hostname, vm_username, vm_password, expected_hostname, command_to_run, ssh_port)

if __name__ == "__main__":
    main(sys.argv[1:])
