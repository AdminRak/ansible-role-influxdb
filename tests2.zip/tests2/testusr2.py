import paramiko
import getopt
import sys

def is_user_existing(username, hostname, ssh_username, ssh_password, ssh_port):
    try:
        # Create an SSH client
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # Connect to the VM with the specified port
        ssh_client.connect(hostname, username=ssh_username, password=ssh_password, port=ssh_port)

        # Execute the 'id' command remotely
        stdin, stdout, stderr = ssh_client.exec_command(f'id {username}')
        
        # Check if the command was successful (user exists)
        if stdout.channel.recv_exit_status() == 0:
            return True
        else:
            return False

    except paramiko.AuthenticationException:
        print("Authentication failed.")
        return False
    except paramiko.SSHException as e:
        print(f"SSH error: {str(e)}")
        return False
    finally:
        # Close the SSH connection
        ssh_client.close()

def main(argv):
    vm_hostname = ''
    ssh_username = ''
    ssh_password = ''
    ssh_port = 22  # Default SSH port
    username_to_check = ''

    try:
        opts, args = getopt.getopt(argv, "h:u:p:P:c:", ["hostname=", "username=", "password=", "port=", "check-user="])
    except getopt.GetoptError:
        print("Usage: validate_user.py -h <hostname> -u <username> -p <password> -P <port> -c <check-user>")
        sys.exit(2)

    for opt, arg in opts:
        if opt in ("-h", "--hostname"):
            vm_hostname = arg
        elif opt in ("-u", "--username"):
            ssh_username = arg
        elif opt in ("-p", "--password"):
            ssh_password = arg
        elif opt in ("-P", "--port"):
            ssh_port = int(arg)
        elif opt in ("-c", "--check-user"):
            username_to_check = arg

    if not vm_hostname or not ssh_username or not ssh_password or not username_to_check:
        print("Missing required arguments.")
        print("Usage: validate_user.py -h <hostname> -u <username> -p <password> -P <port> -c <check-user>")
        sys.exit(2)

    if is_user_existing(username_to_check, vm_hostname, ssh_username, ssh_password, ssh_port):
        print(f"The user '{username_to_check}' exists on the VM.")
    else:
        print(f"The user '{username_to_check}' does not exist on the VM.")

if __name__ == "__main__":
    main(sys.argv[1:])
